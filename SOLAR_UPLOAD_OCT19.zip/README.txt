NO POWER CUT, NO ETC BILL — Solar Energy Website

Contents:
- index.html: responsive English website with solar system descriptions, package prices, calculator, project gallery and contact details.
- package-*.jpg: package promotional artwork supplied by the company.
- project-*.jpeg: actual installation photos supplied in this conversation.
- logo.jpg, banner.jpg, inverter/battery images: original assets where available.

To publish on GitHub Pages:
1. Extract this ZIP.
2. Upload all files and images to the root of your Solar-Website repository (same folder as index.html).
3. Replace existing files when asked.
4. Commit changes, then wait for GitHub Pages to update.

Important: advertised package prices and warranty statements are copied from supplied promotional artwork and should be reconfirmed before publication. The estimator is indicative, not a formal quotation. Project capacities and locations are not stated because they were not provided.

Business contact details included from information supplied: +94 71 114 3289, nopowercut@gmail.com; Head Office: No. 166, Railway Station Road, Warakapola; Branch: No. 163, Ragama Road, Kadawatha.
